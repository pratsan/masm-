package com.xyz.srs.entity.ship;


import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "route")
public class    RouteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int routeId;
    private String source;
    private String destination;
    private int distance;
    @OneToMany(mappedBy = "route")
    List<ShipEntity> shipEntities;

//
//    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
//    @JoinColumn(name = "routes_id")
//    private ShipEntity shipEntities;


    public RouteEntity() {
    }

    public RouteEntity(int routeId, String source, String destination, int distance, List<ShipEntity> shipEntities) {
        this.routeId = routeId;
        this.source = source;
        this.destination = destination;
        this.distance = distance;
        this.shipEntities = shipEntities;
    }

    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public List<ShipEntity> getShipEntities() {
        return shipEntities;
    }

    public void setShipEntities(List<ShipEntity> shipEntities) {
        this.shipEntities = shipEntities;
    }
}