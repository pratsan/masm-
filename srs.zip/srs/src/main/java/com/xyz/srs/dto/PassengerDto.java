package com.xyz.srs.dto;

public class PassengerDto {
    private String passName;

    private String passGender;
    private int passAge;

    public PassengerDto() {
    }

    public PassengerDto(String passName, String passGender, int passAge) {
        this.passName = passName;
        this.passGender = passGender;
        this.passAge = passAge;
    }

    public String getPassName() {
        return passName;
    }

    public void setPassName(String passName) {
        this.passName = passName;
    }

    public String getPassGender() {
        return passGender;
    }

    public void setPassGender(String passGender) {
        this.passGender = passGender;
    }

    public int getPassAge() {
        return passAge;
    }

    public void setPassAge(int passAge) {
        this.passAge = passAge;
    }
}
