package com.xyz.srs.entity.ship;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity
@Table(name = "ship_schedule")
public class ShipScheduleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int scId;
@OneToOne
@JoinColumn(name = "route_id")
    private RouteEntity routeEntity;
    @OneToOne
    @JoinColumn(name = "ship_id")
    private ShipEntity shipEntity;
    private LocalDate date;
    private int seatAvailable;

    public ShipScheduleEntity() {
    }

    public ShipScheduleEntity(int scId, RouteEntity routeEntity, ShipEntity shipEntity, LocalDate date, int seatAvailable) {
        this.scId = scId;
        this.routeEntity = routeEntity;
        this.shipEntity = shipEntity;
        this.date = date;
        this.seatAvailable = seatAvailable;
    }

    public int getScId() {
        return scId;
    }

    public void setScId(int scId) {
        this.scId = scId;
    }

    public RouteEntity getRouteEntity() {
        return routeEntity;
    }

    public void setRouteEntity(RouteEntity routeEntity) {
        this.routeEntity = routeEntity;
    }

    public ShipEntity getShipEntity() {
        return shipEntity;
    }

    public void setShipEntity(ShipEntity shipEntity) {
        this.shipEntity = shipEntity;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getSeatAvailable() {
        return seatAvailable;
    }

    public void setSeatAvailable(int seatAvailable) {
        this.seatAvailable = seatAvailable;
    }
}
