package com.xyz.srs.service;


import com.xyz.srs.dto.UserDto;
import com.xyz.srs.dto.UserResponse;
import com.xyz.srs.entity.user.UserEntity;
import com.xyz.srs.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@Service("userService")

public class UserServiceImpl implements UserService{
@Autowired
    UserRepository userRepository;
//@Autowired
//    HttpSession httpSession;
    @Override
    public UserResponse registerUser(UserDto userDto) {
        UserEntity userEntity = new UserEntity();
        Optional<UserEntity> userByUserEmail = userRepository.findUserByUserEmail(userDto.getUserEmail());
        if (!userByUserEmail.isPresent()) {
            userEntity.setUserMob(userDto.getUserMob());
            userEntity.setUserEmail(userDto.getUserEmail());
            userEntity.setUserName(userDto.getUserName());
            userEntity.setUserPass(userDto.getUserPass());
            userRepository.save(userEntity);
            return new UserResponse("user registered successfully",true);
        }
        else {
            return new UserResponse("user already registered ",false);
        }


    }

    @Override
    public UserResponse validateUserLogin(UserDto userDto) {
        Optional<UserEntity> userByUserEmailAndUserPass = userRepository.findUserByUserEmailAndUserPass(userDto.getUserEmail(), userDto.getUserPass()); userRepository.findUserByUserEmailAndUserPass(userDto.getUserEmail(), userDto.getUserPass());

        if(userByUserEmailAndUserPass.isPresent()){
//            httpSession.setAttribute("userid",userByUserEmailAndUserPass.get().getUserId());
            return new UserResponse("user loogedin successfully",true);
        }
        else{
            return new UserResponse("invalid usernane or password",false);
        }
    }
}
