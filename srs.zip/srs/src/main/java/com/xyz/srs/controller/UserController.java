package com.xyz.srs.controller;
import com.xyz.srs.dto.ShipRequestDto;
import com.xyz.srs.dto.UserDto;
import com.xyz.srs.dto.UserResponse;
import com.xyz.srs.service.UserService;
import com.xyz.srs.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public ModelAndView homePage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("loginPage");
        modelAndView.addObject("registerPage", new UserDto());
        return new ModelAndView("index");
    }

    @GetMapping("/registerPage")
    public ModelAndView registerPage() {
        return new ModelAndView("register", "registerUser", new UserDto());
    }

    @GetMapping("/loginPage")
    public ModelAndView loginPage() {
        return new ModelAndView("login", "userCredentials", new UserDto());
    }

    @PostMapping("/register")
    public ModelAndView submitForm(@ModelAttribute("registerUser") UserDto userDto, Model model) {
        UserResponse b = userService.registerUser(userDto);
        model.addAttribute("userResponse", b);
        if (!b.isStatus()) {

            System.out.println(b);
            return new ModelAndView("/register");
        }
        System.out.println("register");
        return new ModelAndView("/login", "userCredentials", new UserDto());
    }

    @PostMapping("/login")
    public ModelAndView loginUser(@ModelAttribute("userCredentials") UserDto userDto) {
        UserResponse userResponse = userService.validateUserLogin(userDto);
        if (!userResponse.isStatus()) {
            return new ModelAndView("/login");
        } else {
            return new ModelAndView("/dashboard", "search", new ShipRequestDto());
        }
    }
}

