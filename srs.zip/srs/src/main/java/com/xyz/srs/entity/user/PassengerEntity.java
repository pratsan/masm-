package com.xyz.srs.entity.user;

import javax.persistence.*;

@Entity
@Table(name = "passenger")
public class PassengerEntity {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private int passId;
    private String passName;

    private String passGender;
    private int passAge;
    @ManyToOne
    BookingEntity booking;

    public PassengerEntity(int passId, String passName, String passGender, int passAge, BookingEntity booking) {
        this.passId = passId;
        this.passName = passName;
        this.passGender = passGender;
        this.passAge = passAge;
        this.booking = booking;
    }

    public PassengerEntity() {
    }

    public BookingEntity getBooking() {
        return booking;
    }

    public void setBooking(BookingEntity booking) {
        this.booking = booking;
    }

    public int getPassId() {
        return passId;
    }

    public void setPassId(int passId) {
        this.passId = passId;
    }

    public String getPassName() {
        return passName;
    }

    public void setPassName(String passName) {
        this.passName = passName;
    }

    public String getPassGender() {
        return passGender;
    }

    public void setPassGender(String passGender) {
        this.passGender = passGender;
    }

    public int getPassAge() {
        return passAge;
    }

    public void setPassAge(int passAge) {
        this.passAge = passAge;
    }
}
