package com.xyz.srs.repository;

import com.xyz.srs.entity.ship.RouteEntity;
import com.xyz.srs.entity.ship.ShipEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface ShipRepository extends JpaRepository<ShipEntity,Integer> {
//    @Query("select ship from ShipEntity  ship where RouteEntity in :routeId")
//    List<ShipEntity> findAllByRouteEntity(List<RouteEntity> routeId);

}
