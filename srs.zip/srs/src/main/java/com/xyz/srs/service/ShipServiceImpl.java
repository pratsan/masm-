package com.xyz.srs.service;

import com.xyz.srs.dto.ShipRequestDto;
import com.xyz.srs.dto.ShipResponseDto;
import com.xyz.srs.entity.ship.RouteEntity;
import com.xyz.srs.entity.ship.ShipEntity;
import com.xyz.srs.repository.RouteRepository;
import com.xyz.srs.repository.ShipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ShipServiceImpl implements ShipService{
    @Autowired
    ShipRepository shipRepository;
    @Autowired
    RouteRepository routeRepository;


    @Override
    public List<ShipResponseDto> findShipBySourceAndDestination(ShipRequestDto shipDto) {
        List<RouteEntity> routeBySourceAndDestination = routeRepository.findAllBySourceAndDestination(shipDto.getSource(), shipDto.getDestination());
    List<ShipResponseDto> shipResponseDtos=new ArrayList<>();
    routeBySourceAndDestination.stream().forEach(routeEntity -> {


                List<ShipEntity> shipEntities = routeEntity.getShipEntities();
                shipEntities.forEach(shipEntity -> {
                    ShipResponseDto shipResponseDto = new ShipResponseDto();
                    shipResponseDto.setRouteId(routeEntity.getRouteId());
                    shipResponseDto.setShipCapacity(shipEntity.getShipCapacity());
                    shipResponseDto.setShipId(shipEntity.getShipId());
                    shipResponseDto.setShipModel(shipEntity.getShipModel());
                    shipResponseDto.setSource(shipDto.getSource());
                    shipResponseDto.setDestination(shipDto.getDestination());
                    shipResponseDto.setRouteId(routeEntity.getRouteId());
                    shipResponseDtos.add(shipResponseDto);
                });
            });


//        List<ShipEntity> allByRouteId = shipRepository.findAllByRouteEntity(routeList);



        return shipResponseDtos;
    }
}
