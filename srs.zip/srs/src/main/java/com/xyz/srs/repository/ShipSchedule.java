package com.xyz.srs.repository;

import com.xyz.srs.entity.ship.ShipScheduleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ShipSchedule extends JpaRepository<ShipScheduleEntity,Integer>{

}
