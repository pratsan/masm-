package com.xyz.srs.service;

import com.xyz.srs.dto.ShipRequestDto;
import com.xyz.srs.dto.ShipResponseDto;
import com.xyz.srs.entity.ship.ShipEntity;

import java.util.List;

public interface ShipService {
    List<ShipResponseDto> findShipBySourceAndDestination(ShipRequestDto shipDto);
}
