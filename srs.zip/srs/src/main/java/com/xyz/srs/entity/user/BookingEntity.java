package com.xyz.srs.entity.user;

import com.xyz.srs.entity.ship.RouteEntity;
import com.xyz.srs.entity.ship.ShipScheduleEntity;


import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "booking")
public class BookingEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingId;
    @OneToMany(mappedBy = "booking")
//    @JoinColumn(name = "booking_id")
    List<PassengerEntity> passengerEntityList;
    @OneToOne
    @JoinColumn(name="schedule_id")
    ShipScheduleEntity shipScheduleEntity;
    @Column(name = "total_amount")
private int totalAmount;
    @Column(name = "ticket_status")
    private boolean isBooked;
    public BookingEntity() {
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void setBooked(boolean booked) {
        isBooked = booked;
    }

    public BookingEntity(int bookingId, List<PassengerEntity> passengerEntityList, ShipScheduleEntity shipScheduleEntity, int totalAmount, boolean isBooked) {
        this.bookingId = bookingId;
        this.passengerEntityList = passengerEntityList;
        this.shipScheduleEntity = shipScheduleEntity;
        this.totalAmount = totalAmount;
        this.isBooked = isBooked;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public List<PassengerEntity> getPassengerEntityList() {
        return passengerEntityList;
    }

    public void setPassengerEntityList(List<PassengerEntity> passengerEntityList) {
        this.passengerEntityList = passengerEntityList;
    }

    public ShipScheduleEntity getShipScheduleEntity() {
        return shipScheduleEntity;
    }

    public void setShipScheduleEntity(ShipScheduleEntity shipScheduleEntity) {
        this.shipScheduleEntity = shipScheduleEntity;
    }
}
