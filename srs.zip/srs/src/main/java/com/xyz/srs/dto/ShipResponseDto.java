package com.xyz.srs.dto;

public class ShipResponseDto {
private int routeId;
private String source;
private String destination;
private int shipId;
private String shipModel;
private String shipCapacity;

    public ShipResponseDto() {
    }

    public ShipResponseDto(int routeId, String source, String destination, int shipId, String shipModel, String shipCapacity) {
        this.routeId = routeId;
        this.source = source;
        this.destination = destination;
        this.shipId = shipId;
        this.shipModel = shipModel;
        this.shipCapacity = shipCapacity;
    }

    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getShipId() {
        return shipId;
    }

    public void setShipId(int shipId) {
        this.shipId = shipId;
    }

    public String getShipModel() {
        return shipModel;
    }

    public void setShipModel(String shipModel) {
        this.shipModel = shipModel;
    }

    public String getShipCapacity() {
        return shipCapacity;
    }

    public void setShipCapacity(String shipCapacity) {
        this.shipCapacity = shipCapacity;
    }
}
