package com.xyz.srs.service;

import com.xyz.srs.dto.BookingResponseDto;

import java.util.List;

public interface BookingService {
    public BookingResponseDto book(List<String>names, List<Integer>age, List<String>gender);
}
