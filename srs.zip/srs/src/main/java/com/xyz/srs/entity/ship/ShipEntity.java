package com.xyz.srs.entity.ship;


import javax.persistence.*;

@Entity
@Table(name = "ship")
public class ShipEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int shipId;
    private String shipModel;
    private String shipCapacity;
    @ManyToOne()
 @JoinColumn(name="route_id")
    RouteEntity route;

    public ShipEntity() {
    }

    public ShipEntity(int shipId, String shipModel, String shipCapacity, RouteEntity route) {
        this.shipId = shipId;
        this.shipModel = shipModel;
        this.shipCapacity = shipCapacity;
        this.route = route;
    }

    public int getShipId() {
        return shipId;
    }

    public void setShipId(int shipId) {
        this.shipId = shipId;
    }

    public String getShipModel() {
        return shipModel;
    }

    public void setShipModel(String shipModel) {
        this.shipModel = shipModel;
    }

    public String getShipCapacity() {
        return shipCapacity;
    }

    public void setShipCapacity(String shipCapacity) {
        this.shipCapacity = shipCapacity;
    }

    public RouteEntity getRoute() {
        return route;
    }

    public void setRoute(RouteEntity route) {
        this.route = route;
    }
}