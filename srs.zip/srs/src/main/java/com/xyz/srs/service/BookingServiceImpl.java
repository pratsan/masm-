package com.xyz.srs.service;

import com.xyz.srs.dto.BookingResponseDto;
import com.xyz.srs.dto.PassengerDto;
import com.xyz.srs.entity.ship.RouteEntity;
import com.xyz.srs.entity.ship.ShipEntity;
import com.xyz.srs.entity.ship.ShipScheduleEntity;
import com.xyz.srs.entity.user.BookingEntity;
import com.xyz.srs.entity.user.PassengerEntity;
import com.xyz.srs.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService{
    @Autowired
    HttpSession httpSession;
   @Autowired
    BookingRepository bookingRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    RouteRepository routeRepository;
    @Autowired
    ShipRepository shipRepository;
    @Autowired
    ShipSchedule shipSchedule;
    @Autowired
    PassengerRepository passengerRepository;
    int shipPerKMCharge=2;

    @Override
    public BookingResponseDto book(List<String> names, List<Integer> age, List<String> gender) {
        Object user = httpSession.getAttribute("user");
        List<PassengerEntity> passengerDtos=new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            PassengerEntity passengerDto=new PassengerEntity();
            passengerDto.setPassAge(age.get(0));
            passengerDto.setPassName(names.get(0));
            passengerDto.setPassGender(gender.get(0));
            passengerDtos.add(passengerDto);
        }
        BookingEntity bookingEntity=new BookingEntity();
        bookingEntity.setPassengerEntityList(passengerDtos);
//        route entity
        Optional<RouteEntity> routeId = routeRepository.findById(Integer.parseInt(httpSession.getAttribute("routeId").toString()));
        Optional<ShipEntity> shipId = shipRepository.findById(Integer.parseInt(httpSession.getAttribute("shipId").toString()));
        List<ShipScheduleEntity> all = shipSchedule.findAll();
        ShipScheduleEntity shipScheduleEntity1 = all.stream()
                .filter(shipScheduleEntity ->
                        shipScheduleEntity.getRouteEntity().getRouteId() == routeId.get().getRouteId()
                                && shipScheduleEntity.getShipEntity().getShipId() == shipId.get().getShipId())
                .findAny()
                .get();
        bookingEntity.setShipScheduleEntity(shipScheduleEntity1);
        bookingEntity.setPassengerEntityList(passengerDtos);
        bookingEntity.setTotalAmount(((routeId.get().getDistance()*shipPerKMCharge)* passengerDtos.size()));
        bookingEntity.setBooked(true);
//        insert data in booking table
        BookingEntity bookingEntity1 = bookingRepository.saveAndFlush(bookingEntity);
        passengerDtos.forEach(passengerEntity -> passengerEntity.setBooking(bookingEntity1));
//        insert data in passenger table
        passengerRepository.saveAll(passengerDtos);
BookingResponseDto bookingResponseDto=new BookingResponseDto(bookingEntity1.getBookingId(), passengerDtos.size(),
        bookingEntity1.getTotalAmount(), shipId.get().getShipId(),shipId.get().getShipModel(),routeId.get().getSource(),routeId.get().getDestination());
return bookingResponseDto;



    }
}
