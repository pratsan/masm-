package com.xyz.srs.repository;

import com.xyz.srs.entity.ship.RouteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RouteRepository extends JpaRepository<RouteEntity,Integer> {
//    @Query("select route from RouteEntity route where route.source=:source and route.destination=:destination")
    List<RouteEntity> findAllBySourceAndDestination(@Param("source") String source,@Param("destination") String destination);
}
