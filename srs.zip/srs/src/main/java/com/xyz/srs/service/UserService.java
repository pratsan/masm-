package com.xyz.srs.service;

import com.xyz.srs.dto.UserDto;
import com.xyz.srs.dto.UserResponse;
import com.xyz.srs.entity.user.UserEntity;

public interface UserService {
    UserResponse registerUser(UserDto userDto);
    UserResponse validateUserLogin(UserDto userDto);
}
