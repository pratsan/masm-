package com.xyz.srs.entity.user;

import javax.persistence.*;
import java.util.List;
@Entity
@Table(name = "users")
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;

    @Column(unique = true)
    private String userEmail;
    private String userPass;
    private String userName;
    private String userMob;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private List<BookingEntity> bookingEntityList;

    public UserEntity() {
    }

    public UserEntity(int userId, String userEmail, String userPass, String userName, String userMob, List<BookingEntity> bookingEntityList) {
        this.userId = userId;
        this.userEmail = userEmail;
        this.userPass = userPass;
        this.userName = userName;
        this.userMob = userMob;
        this.bookingEntityList = bookingEntityList;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMob() {
        return userMob;
    }

    public void setUserMob(String userMob) {
        this.userMob = userMob;
    }

    public List<BookingEntity> getBookingEntityList() {
        return bookingEntityList;
    }

    public void setBookingEntityList(List<BookingEntity> bookingEntityList) {
        this.bookingEntityList = bookingEntityList;
    }
}