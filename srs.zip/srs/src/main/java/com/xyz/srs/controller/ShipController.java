package com.xyz.srs.controller;

import com.xyz.srs.dto.ShipRequestDto;
import com.xyz.srs.dto.ShipResponseDto;
import com.xyz.srs.repository.RouteRepository;
import com.xyz.srs.service.ShipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/ship")
public class ShipController {

    @Autowired
    private RouteRepository shipRepository;
    @Autowired
    private ShipService shipService;

    @PostMapping("/search")
    public ModelAndView findShip(@ModelAttribute("search") ShipRequestDto shipDto){
        List<ShipResponseDto> shipBySourceAndDestination = shipService.findShipBySourceAndDestination(shipDto);
    ModelAndView modelAndView=new ModelAndView();
      modelAndView.addObject("shipDetails",shipBySourceAndDestination);
      modelAndView.setViewName("/search-result");
        return modelAndView;
    }




}
