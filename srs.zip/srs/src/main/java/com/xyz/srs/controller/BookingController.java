package com.xyz.srs.controller;

import com.xyz.srs.dto.BookingResponseDto;
import com.xyz.srs.dto.PassengerDto;
import com.xyz.srs.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class BookingController {
    @Autowired
    HttpSession httpSession;
    @Autowired
    BookingService bookingService;
    @GetMapping("/booking")
public ModelAndView getBookingPage(@RequestParam("shipId")String shipId,@RequestParam("routeId")String routeId){
        httpSession.setAttribute("routeId",routeId);
        httpSession.setAttribute("shipId",shipId);

    return new ModelAndView("booking_page","passengers",new ArrayList<PassengerDto>());
}
@PostMapping("/bk")
    public ModelAndView bk(HttpServletRequest httpServletRequest) {
    List<String> name = Arrays.asList(httpServletRequest.getParameterValues("name"));
    List<String> collect = name.stream().filter(n -> !n.isEmpty()).collect(Collectors.toList());
    List<String> gender = Arrays.asList(httpServletRequest.getParameterValues("gender"));

    List<Integer> age = Arrays.stream(httpServletRequest.getParameterValues("age")).collect(Collectors.toList())
            .stream()
            .filter(d -> !d.isEmpty())

            .map(d -> Integer.valueOf(d))
            .collect(Collectors.toList());
    BookingResponseDto book = bookingService.book(collect, age, gender);
    ModelAndView modelAndView=new ModelAndView("ticket","bookingDetails",book);
    return modelAndView;
}

}
