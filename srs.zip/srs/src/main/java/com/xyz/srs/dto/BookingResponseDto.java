package com.xyz.srs.dto;

public class BookingResponseDto {
    private int bookingId;
    private int numberOfPassenger;
    private int bookingPrice;
    private int shipId;
    private String shipModel;
    private String source;
    private String destination;

    public BookingResponseDto(int bookingId, int numberOfPassenger, int bookingPrice, int shipId, String shipModel, String source, String destination) {
        this.bookingId = bookingId;
        this.numberOfPassenger = numberOfPassenger;
        this.bookingPrice = bookingPrice;
        this.shipId = shipId;
        this.shipModel = shipModel;
        this.source = source;
        this.destination = destination;
    }

    public int getBookingId() {
        return bookingId;
    }

    public int getNumberOfPassenger() {
        return numberOfPassenger;
    }

    public int getBookingPrice() {
        return bookingPrice;
    }

    public int getShipId() {
        return shipId;
    }

    public String getShipModel() {
        return shipModel;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }
}
