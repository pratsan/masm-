package com.xyz.srs.dto;

import com.xyz.srs.entity.user.UserEntity;

public class UserDto {
    private String userEmail;
    private String userPass;
    private String userName;
    private String userMob;

    public UserDto() {
    }

    public UserDto(String userEmail, String userPass, String userName, String userMob) {
        this.userEmail = userEmail;
        this.userPass = userPass;
        this.userName = userName;
        this.userMob = userMob;
    }

    public UserDto(String userEmail, String userPass) {
        this.userEmail = userEmail;
        this.userPass = userPass;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMob() {
        return userMob;
    }

    public void setUserMob(String userMob) {
        this.userMob = userMob;
    }

//    method to convert User entity to UserDto
    public static UserDto entityToDto(UserEntity user) {
        return new UserDto(user.getUserName(), user.getUserEmail(), user.getUserPass(), user.getUserMob());
    }

    // Method to convert UserDto to User entity
    public UserEntity dtoToEntity() {
        UserEntity user = new UserEntity();
        user.setUserName(this.getUserName());
        user.setUserEmail(this.getUserEmail());
        user.setUserPass(this.getUserPass());
        user.setUserMob(this.getUserMob());
        return user;
    }
}
