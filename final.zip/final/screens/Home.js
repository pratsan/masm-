import React from 'react'
import Header from '../screens/Header'
import {NavigationPage} from '../screens/NavigationPage'
import {ROUTER_DATA} from '../router/Routes'
import { Route, Router, Switch } from 'react-router-dom'
import Dashboard from './Dashboard'

const Home =(props)=>{
    console.log(props.ROUTER_DATA)
   
    return(
    <div>

<Router>
<Switch>

    <Route exact  path="/" render={props=><Header {...props} ROUTER_DATA={ROUTER_DATA} />}/>
    <Route exact  path="/nav" component={Dashboard}/>
   
    </Switch>
    </Router>



    </div>
    );
    
}
function NavPage(){
 console.log("wer")
    // {ROUTER_DATA.map((data,key)=>{
    //     console.log("value of data", data.visible);
    return <Dashboard/>;
        
    // })
// }
}
export default Home