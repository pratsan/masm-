import React from 'react'
import {AppBar,Toolbar,Typography,IconButton, Button} from '@material-ui/core'
const CartFooter=props=>{
    return(
    <AppBar position="fixed" onClick={()=>alert("cl")} color="primary" style={{ top: 'auto',
    bottom: 0}}>
        <Toolbar>

        <Typography variant="h5">Proceed to pay</Typography>

          <div style={{flexGrow:1}} />
       
          <IconButton edge="end" color="default" >
            {props.totalPrice}
          </IconButton>
        </Toolbar>
      </AppBar>
     
    )
}
export default CartFooter;