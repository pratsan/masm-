import { ButtonBase, Card, CardContent, Container, Grid, Hidden, Paper, Typography } from '@material-ui/core'
import React from 'react'
import Logo from '../assests/percipio.jpg'
import {NavigationCss} from '../css/NavigationPageCss'

export const NavigationPage=(props)=>{
    const navigationStyles=NavigationCss;
    const classes=navigationStyles();
  const { history } = props;
  const dashboardImage=[
    {
      id:1,
      productName:'veggies',
      image:"https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,w=853,h=292/layout-engine/2020-12/01_9.png",
      onClick:()=>{
        console.log(props)
        history.push(`/specific_product/veggies`);
      }
    },
    {
      id:2,
      productName:'alcohol',
      image:"https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,w=853,h=292/layout-engine/2020-12/04-copy_0.png"
    },
    {
      id:1,
      productName:'veggies',
      image:"https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,w=853,h=292/layout-engine/2020-12/04-copy_0.png",
      onClick:()=>{
        console.log(props)
        history.push(`/specific_product/veggies`);
      }
    },
    {
      id:2,
      productName:'alcohol',
      image:"https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=50,w=853,h=292/layout-engine/2020-12/04-copy_0.png"
    },
  ]
    return(
     
       
                <Grid container direction="row" spacing={2} className={classes.root}> 
                  
                  {dashboardImage.map((data,key)=>{
                    const {productName,image,onClick} =data
                      return(
                          <Grid item sm={6} md={5
                          } lg={3}  key={key.toString()}>
                  <Card  key={key.toString()}>
                      <CardContent style={{padding:0}}>
               <ButtonBase  key={key.toString()} onClick={onClick}>
                 <img key={key.toString()} src= {image} className={classes.image}/>

                 </ButtonBase>
                 </CardContent>
                 </Card>
                 </Grid>
                   )})}
                 </Grid>
            
    )
    
}