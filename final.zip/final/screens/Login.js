import React, { useState } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import {loginCssStyle} from '../css/Logincss'
import Container from '@material-ui/core/Container';
import {Router,NavLink,Switch, withRouter} from 'react-router-dom'

  function SignIn() {
  return (
   <div></div>
  );
}



 function Login(props) {
  
  const [data,setData]=useState(null);
   const {history}=props;
    const loginCssStyles=loginCssStyle;
  const classes = loginCssStyles();

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <form className={classes.form} noValidate>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="phone"
            label="phone number"
            name="phone"
            autoComplete="true"
            autoFocus
          />
        
          
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            
          >
            Sign In
          </Button>
         
        </form>
      </div>
      <Box mt={8}>
        <SignIn/>
      </Box>
   
      <div className={classes.otp}>
      <TextField
            variant="outlined"
            type="number"
           
            style={{width:100,height:50,textAlign:'center'}}
        onChange={ots}
          />
      <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={()=>validate()}
            
          >
            otp In
          </Button>
  <Typography variant="button" color="primary" >
Otp not recieved yet? click here

  </Typography>
      </div>
    </Container>
    
  );
  function ots(event){
   
   setData(event.target.value);
  }
  function validate(){
    props.login(localStorage.setItem("id",5));
  }
}
export default withRouter(Login)