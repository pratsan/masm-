import React, { useState,useEffect } from 'react'
import Grid from '@material-ui/core/Grid'
import Logo from '../assests/percipio.jpg'
import {NavigationPage} from '../screens/NavigationPage'
import { getProduct } from "../states/ProductAction";
import {increment,decrement} from '../states/Actions'
import { Snackbar, Typography,Card,CardContent,CardActions,Button, makeStyles, CardMedia, Hidden } from '@material-ui/core'
import { connect } from 'react-redux'
import { Alert, AlertTitle } from '@material-ui/lab';
import {DashboardCss} from '../css/DashboardCss'
const Dashboard=(props)=>{
  const DashboardCssStyle=DashboardCss;
  const classes=DashboardCssStyle();
const [isopen,setOpen]=useState(false);
const [data,setData]=useState([])
useEffect(()=>{
props.getProduct();
fetchProduct()

},[])
 
function fetchProduct(){
  setTimeout(()=>alert("demo"),900)
  setData(props.product);
  console.log(data)
}
    

      function  increment(i){

        props.increment(i);
        setOpen(true);
       
  
  }
  function closeSnackbar()
  {
    setOpen(false);
  }


  
  
   

    



function GridFunction(){

  
       return(
         
            data.map((data,i)=>(
          <Grid container item xs={6} md={3} lg={4} key={i} > 
          <Card className={classes.root}>
      
        <CardMedia 
            component="img"
            alt="Contemplative Reptile"
            height="200"
            width="200"
            image={data.imageUrl}
            src="image"
            title="Contemplative Reptile"
          />
           
          <CardContent>
            <Typography  variant="inherit">
           {data.productName}
            </Typography>
            
            <Typography  variant="inherit" component="h5">
              Quantity:{data.quantity}
            </Typography>
            <Typography gutterBottom={true} variant="overline" component="h5" color="error">
              Price:{data.price}
            </Typography>
          
  
          </CardContent>
     
        <CardActions className={classes.addToCart}>
         
          <Button style={{display:"flex"}} variant="contained" size="medium" color="primary" gutterBottom="true" onClick={()=>increment(data)} key={i} >
            Add To Cart
          </Button>
         
        </CardActions>
      </Card>
         </Grid>
       
            )));

         
       
       
     
  }
return(
    <div>
       <Snackbar open={isopen} autoHideDuration={3000} onClose={closeSnackbar}>
        <Alert  severity="success">
       <Typography variant="p">Added to cart</Typography>
        </Alert>
        </Snackbar>
    <NavigationPage {...props}/>
  <Grid container  spacing={2} style={{backgroundColor:'white',flexGrow:1}}  >
<GridFunction/>

</Grid>

</div>
)
}
const mapDispatchToProps = {
  increment,
  decrement,
  getProduct,
};
const mapStateToProps = state => ({
  product: state.ProductReducer.data
});

export default connect(mapStateToProps,mapDispatchToProps)( Dashboard);