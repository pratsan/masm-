import React from 'react'
import {connect} from 'react-redux'
import {Grid,Button,CardMedia,Card,CardContent,Typography,CardActions} from '@material-ui/core'
import {SpecificProductCss} from '../css/SpecificProductCss'
const SpecificProduct=props=>{
    console.log(props)
    const { match, history } = props;
    const { params } = match;
    const { specific_product_id } = params;
   

    const SpecificProductStyles=SpecificProductCss;
  const classes = SpecificProductStyles();
    const data=[
        {
        id:1,
        product:'beer'  ,
        quantity:1,
        price:20
        },
        {
        id:2,
        product:'vodka'  ,
        quantity:1,
        price:10
        
        },
        {
          id:3,
          product:'prateek'  ,
          quantity:1,
          price:20
          
          },
          {
            id:4,
            product:'prateek'  ,
            quantity:1,
            price:20
            
            },
        
        
         ]    


    return(
        <Grid container  spacing={2} className={classes.root}  >
        {data.map((data,i)=>(
      <Grid container item xs={6} md={3} lg={2} spacing-xs-6 > 
      <Card className={classes.root}>
  
    <CardMedia 
        component="img"
        alt="Contemplative Reptile"
        height="200"
        width="200"
        image=""
        src="image"
        title="Contemplative Reptile"
      />
       
      <CardContent>
        <Typography  variant="p">
          {data.product}
        </Typography>
        
        <Typography  variant="inherit" component="h5">
          {data.quantity}
        </Typography>
        <Typography gutterBottom={true} variant="overline" component="h5" color="error">
          {data.price}
        </Typography>
      

      </CardContent>
 
    <CardActions className={classes.addToCart}>
     
      <Button  variant="contained" size="medium" color="primary" gutterBottom="true"  key={i} >
        Add To Cart
      </Button>
    </CardActions>
  </Card>
     </Grid>
   
        ))}
        </Grid>
        );
 
}


const mapStateToProps = state => ({
    currentCount: state.cartReducer.data.length
  });
  
  const mapDispatchToProps = {
    
  };
  
  
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  ) (SpecificProduct);
  