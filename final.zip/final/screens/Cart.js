
import { Button,Grid, Typography,AppBar,IconButton,Toolbar, CardContent,CardMedia, Card, Container } from '@material-ui/core'
import React from 'react'
import { connect } from 'react-redux';
import CancelIcon from '@material-ui/icons/Cancel';
import CartFooter from './CartFooter'
import { decrementQuantity, addMoreQuantity,deleteCart } from "../states/Actions";
import {CartCss} from '../css/CartCss'

function Cart(props){
  const CartCssStyles=CartCss;
  const classes=CartCssStyles();
  function add(data){
    console.log("cart",data);
    props.addMoreQuantity(data);
  }
  let totalPrice=0;
    return(
   <div style={{marginTop:30}}>
  
 <Grid container  direction="row" spacing={2} className={classes.gridContainer}>
     {props.currentCount.map((data,key)=>{
       totalPrice+=data.totalPrice;
return(

    <Grid item container xs={12} direction="row" className={classes.gridContainer_child}>

        <Grid item xs={12}>
            <Card style={{display:"flex",}}>
                <div className={classes.cardImageContainer}>
        <img src={data.imageUrl} 
       className={classes.cardImage}/>          
       {/* image */}
        </div>
        <CardContent style={{flexGrow:1}}>
      <div className={classes.cardMainContent}>
    
        <Typography className={classes.cardDescription}> Quantity:{data.quantity} Price:{data.quantity*data.price}</Typography>
        </div>
        <div className={classes.cardAction}>
     
        <Button  className={classes.card_child_action} onClick={()=>props.decrementQuantity(data)} > 
        
        <Typography variant="p" >-</Typography>

        </Button>
        <Typography variant="h6" style={{marginRight:10}}>{data.quantity}</Typography>
        <Button className={classes.card_child_action} onClick={()=>add(data)}>
        <Typography variant="caption">+</Typography>
        </Button>
      
                  </div>
                 
        </CardContent>
    
          <IconButton onClick={()=>props.deleteCart(data)}>
                 <CancelIcon fontSize="medium"></CancelIcon>
                 </IconButton>
             
        </Card>
</Grid>

  </Grid>
)})}

 </Grid>
  <CartFooter totalPrice={totalPrice}></CartFooter>


   </div>
    );
}

const mapStateToProps = state => ({
  currentCount: state.cartReducer.data
});

const mapDispatchToProps =  {
  addMoreQuantity,
  decrementQuantity,
  deleteCart
};


export default connect(mapStateToProps,mapDispatchToProps) (Cart);