import { makeStyles,useTheme } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import PropTypes from "prop-types";
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Drawer from '@material-ui/core/Drawer'
import List from '@material-ui/core/List'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import{useEffect, useState} from 'react'
import CancelIcon from '@material-ui/icons/Cancel';
import BusinessCenterOutlinedIcon from '@material-ui/icons/BusinessCenterOutlined';
import Divider from '@material-ui/core/Divider'
import HomeIcon from '@material-ui/icons/Home'
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import ShoppingBasketIcon from '@material-ui/icons/ShoppingBasket';
import Badge from '@material-ui/core/Badge';
import {headerCss} from '../css/HeaderCss'
import {connect, useSelector} from 'react-redux'
import store from '../states/store';
import { increment, decrement } from "../states/Actions";


const  Header= props=> {

  function openDrawer(){
    setOpen(true);
      }
      function hideDrawer()
      {
       setOpen(false);
      } 
  const { history } = props;
 
  const [isOpen,setOpen]=useState(false);
  const headerCssStyles=headerCss;
  const classes = headerCssStyles();
  const itemList=
    [
      {
        text:'Home',
      onClick:()=>{
  history.push("/");
  hideDrawer();
   
      },
      icon:<HomeIcon/>
      }, 
      {
        text:'My Orders',
        onClick:()=>{
         
          history.push("/cart");
          hideDrawer();
    
          },
          icon:<ShoppingCartIcon/>
      },
       {
         text:'Address',
         onClick:()=>{

         },
         icon:<BusinessCenterOutlinedIcon/>

        }
     
    ];
    
    
  return (
    
    <div className={classes.root}>
      <AppBar position="fixed"  className={classes.appbar} >
        <Toolbar>
          <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu" onClick={openDrawer}>
            <MenuIcon  />
          </IconButton>
          <Typography variant="h6" className={classes.title}>
            Pratsan
          </Typography>
          <IconButton aria-label="cart" onClick={()=>history.push("/cart")} >
          <Badge badgeContent={props.currentCount} color="secondary">
          <ShoppingBasketIcon />
          
          </Badge>
        </IconButton>
        
        </Toolbar>
      </AppBar>
     
      <Drawer
          
          variant="persistent"
          classes={{
            paper: classes.drawerPaper
          }}
          open={isOpen}
        
          
        >
          <List className={classes.closeDrawerIcon}>
          <ListItem button onClick={hideDrawer}>
              <ListItemIcon>
                <CancelIcon fontSize="large" />
              </ListItemIcon>
              <ListItemText  />
              </ListItem>
          </List>
          <Divider style={{background:'red'}}/>
          {/* <div className={classes.toolbar} /> */}
          
          <List className={classes.nav} >
          { itemList.map((data,key)=>{
            const{text,onClick,icon}=data
            return(
            <ListItem button onClick={onClick} key={data.text}>
              <ListItemIcon>
              {icon}
              </ListItemIcon>
              <ListItemText primary={text} />
              <Divider/>
            </ListItem>
        
            )
            
          })}
           
          </List>
        </Drawer>
     
    </div>

 
  );

 
}

// Header.propTypes = {
//   classes: PropTypes.object.isRequired
// }; 

const mapStateToProps = state => ({
  currentCount: state.cartReducer.data.length
 
});

const mapDispatchToProps = {
  increment,
  decrement
};


export default connect(
  mapStateToProps,
  mapDispatchToProps
) (Header);
