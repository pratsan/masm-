export function getProduct(){
    return function(dispatch){
      fetch("http://192.168.0.103:8000/products/").then(response=> response.json())
      .then((result)=>dispatch({
     type:'FETCH_PRODUCT',
     payload:result.product   
      }));
  
    }
  }