import { decrementQuantity } from "./Actions";
import axios from 'axios'

let initialState = {
     data:[
      
        ]

  }
  
  
  export default  (state = initialState, action) => {
    let index=-1;
    let a=Object;
    switch (action.type) {

      case "INCREMENT":
        index=state.data.findIndex(e=>e.id ===action.payload.productId)
  console.log("printing axtion id",action.payload.productId)
      let a=JSON.parse(JSON.stringify(state.data));
    
      if(index!==-1)
      {
      
         
          console.log( "if part");
       console.log(a);
          console.log(parseInt(a[index]['quantity']));
          a[index]['quantity']+=1
          a[index]['totalPrice']= a[index]['quantity']*a[index]['price'];
        
          state = Object.assign({}, state, { data:a});
         
          return state;
          
      }
    
        
   else{
    console.log("else part")

   
   a=Object.assign({},action.payload ,{totalPrice:action.payload.quantity*action.payload.price});

 
    console.log(a)

      return {    
        ...state,    
        data: state.data.concat(a)    
    }
  }
   
          
 
      case "DECREMENT":
        return 1;

        case "CART":
try{
  console.log("carting!!!!!!!")
          // axios.get({
          //   method:'GET',
          //   url:'http://192.168.0.103:8000/products/',
          //   headers:{
          //     Accept: 'application/json',
          //   }
         
          // }).then(response=>{
          //   const product=response.data;
          //   console.log(product);
          //   state = Object.assign({}, state, { data:product});
          // })
        console.log("payload",action.payload)

   state = Object.assign({}, state, { data:action.payload});
     
          
        
          
         return {...state}
        }
        catch(error)
        {
          console.log(error.toString())
        }
       

            case 'UPDATE_DECREMENT_CART':
               index=state.data.findIndex(e=>e.id ===action.payload.id)
  
              const decrementCart=JSON.parse(JSON.stringify(state.data));
            console.log(decrementCart);
            console.log("updating cart" ,parseInt(decrementCart[index]['quantity']))
                if(index!==-1 && parseInt(decrementCart[index]['quantity'])>1 )
              {
                 
                  console.log( decrementCart[index]['product']);
               console.log(decrementCart);
                  console.log(parseInt(decrementCart[index]['quantity']));
                  decrementCart[index]['quantity']-=1
                  decrementCart[index]['totalPrice']= decrementCart[index]['quantity']*decrementCart[index]['price'];
                
                  state = Object.assign({}, state, { data:decrementCart});
                  return state;
                  
              }
              return{
                ...state
              }
          
          
              
              case 'UPDATE_INCREMENT_CART':
                 index=state.data.findIndex(e=>e.id ===action.payload.id)
  
               const addCart=JSON.parse(JSON.stringify(state.data));
           console.log("updating cart" ,parseInt(addCart[index]['quantity']))
                if(index!==-1 && parseInt(addCart[index]['quantity'])>0 )
                {
                 
                    console.log( addCart[index]['product']);
                
                    console.log(parseInt(addCart[index]['quantity']));
                    addCart[index]['quantity']+=1
                    addCart[index]['totalPrice']= addCart[index]['quantity']* addCart[index]['price'];
                   
                    console.log("quantity", addCart[index]['quantity']);
                    console.log("price", addCart[index]['price']);
                    state = Object.assign({}, state, { data:addCart});
                    return state;
                    
                }
            
                return null;     

              case 'DELETE_CART':
                index=state.data.findIndex(e=>e.id ===action.payload.id)
  
                const deleteCart=JSON.parse(JSON.stringify(state.data));
                if(index!==-1){
                  deleteCart.splice(index, 1);
                }
                state = Object.assign({}, state, { data: deleteCart});
            return state;

      default:
        return state;
    }
  };