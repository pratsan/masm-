import {combineReducers, configureStore, createStore,applyMiddleware} from '@reduxjs/toolkit';
import thunk from 'redux-thunk'
import cartReducer from './cartReducer'
import ProductReducer from './ProductReducer'

const middleware=[thunk];
const reducer=combineReducers({
    cartReducer:cartReducer,
    ProductReducer:ProductReducer
});
const  store=createStore(
  reducer,
  applyMiddleware(...middleware)
);

export default store;