let initialState = {
    data:[
    
       ]

 }
 
 
 export default  (state = initialState, action) => {
   let index=-1;
   let a=Object;
   switch (action.type) {

       case "FETCH_PRODUCT":
try{
       console.log("payload",action.payload)

  state = Object.assign({}, state, { data:action.payload});
        return {...state}
       }
       catch(error)
       {
         console.log(error.toString())
       }
      


     default:
       return state;
   }
 };