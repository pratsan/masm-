export const increment = (product) => ({
    type: "INCREMENT",
    payload:product
  });
  
  export const decrement = (product) => ({
    type: "DECREMENT",
    payload:product
  });

  function fetchProduct(){
    var product=null;
   fetch("http://192.168.0.103:8000/products/").then(response=> response.json())
    .then((result)=>{
product =result.product;

    });
  return product;
  }

export function getCart(){
  return function(dispatch){
    fetch("http://192.168.0.103:8000/products/").then(response=> response.json())
    .then((result)=>dispatch({
   type:'CART',
   payload:result.product   
    }));

  }
}

  export const getCarts=()=> (
   {
   
    type: "CART",
    payload: fetchProduct(),
    
  });

  export const addMoreQuantity=(product)=>({
    
type:'UPDATE_INCREMENT_CART',
payload:product,
  });

  export const decrementQuantity=(product)=>({
    type:'UPDATE_DECREMENT_CART',
    payload:product,
      });

      export const deleteCart=(product)=>({
        type:'DELETE_CART',
        payload:product,
          });   