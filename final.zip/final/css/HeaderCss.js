import { makeStyles } from '@material-ui/core/styles';
export const headerCss = makeStyles((theme) => ({
    root: {
      
      marginRight:0,
      padding:0,
      
    },  
    appbar:{
      [theme.breakpoints.down('sm')]: {
        backgroundColor: '#ffb74d'},
        margin:0,
        padding:0
  
    
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
     flexGrow:0.8
    },
    drawer:{
      width:'50%',
    },
    closeDrawerIcon:{
        alignSelf:"flex-end",
        color:'grey'
    },
    nav:{
     
        padding:10
    }
  }));
  