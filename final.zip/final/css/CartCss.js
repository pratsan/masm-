import { makeStyles } from '@material-ui/core/styles';
export const CartCss = makeStyles((theme) => ({
    gridContainer:{
       marginTop:'30px'
    },
    gridContainer_child:{
       marginTop:'40px',
    },
    cardImageContainer:{
        display:"flex",
        flexDirection:"row",
       flexGrow:1,
        
        padding:theme.spacing(2)
     },
     cardImage:{
        [theme.breakpoints.only('lg')]:{
        width:320,
        height:120
        },
         width:120
     },
     cardMainContent:{
       display:"flex",
       flexDirection:"row",
       flexGrow:1,alignItems:'center',
       justifyContent:'center',
       paddingTop:10 
     },
     cardDescription:{
        display:"flex",
        flexDirection:"row",
        flexGrow:1,alignItems:'center',
        justifyContent:'center',
        paddingTop:10 ,
       
    alignSelf:'center'
     },
     cardAction:{
     
        display:"flex",
       flexDirection:"row",
       flexGrow:1,
       alignItems:'center',
       justifyContent:'center',
       paddingTop:10 ,
       
    },
    card_child_action:{
      
     
        border:'1px solid black',
        marginRight:10,
        color:'orange',
        fontSize:12
    }
    
}));