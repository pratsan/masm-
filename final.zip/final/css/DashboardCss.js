import { makeStyles } from '@material-ui/core/styles';

export const DashboardCss = makeStyles((theme) => ({
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9,
        marginTop:'30'
      },
      root:{
      },
      addToCart:{
      
    alignItems: 'center',
    
   
    backgroundColor: 'aquamarine',
     justifyContent: 'center',
     
      }
}));