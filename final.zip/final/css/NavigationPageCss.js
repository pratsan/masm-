import { makeStyles } from '@material-ui/core/styles';

export const NavigationCss = makeStyles((theme) => ({
root:{
    justifyContent:'space-evenly',
    marginTop:'80px',
    
    [theme.breakpoints.up('md')]:{
    flexGrow:1,
   aliginItems:'center',
    justifyContent:'flex-start',
    padding:theme.spacing(2),
   
    },
},
image:{
    width:'auto',
    height:150,
    [theme.breakpoints.between(600,1960)]:{
        display:'flex',
        
        padding:10,
       
    height: '100%',
  
  
    width: '100%',
  
    }

}
}));