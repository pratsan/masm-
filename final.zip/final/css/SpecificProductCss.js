import { makeStyles } from '@material-ui/core/styles';
export const SpecificProductCss = makeStyles((theme) => ({

    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9,
        marginTop:'30'
      },
      root:{
          marginTop:50,
      
        flexGrow:1,
        justifyContent:'space-around'
      },
      addToCart:{
      
    alignItems: 'center',
    
   
    backgroundColor: 'aquamarine',
     justifyContent: 'center',
     
      }


    }));