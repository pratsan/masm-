

export let ROUTER_DATA=[{
    page:"dashboard",
    visible:true
},
{
    page:"login",
    visible:false
},
];
