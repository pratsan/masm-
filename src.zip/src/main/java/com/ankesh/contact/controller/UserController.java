package com.ankesh.contact.controller;

import com.ankesh.contact.domain.Contact;
import com.ankesh.contact.domain.ResponseDto;
import com.ankesh.contact.domain.User;
import com.ankesh.contact.domain.UserDto;
import com.ankesh.contact.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Objects;

@Controller
@RequestMapping("user")
public class UserController {
   @Autowired
   UserServiceImpl userService;

   @PostMapping("/register")
   public ModelAndView register(@ModelAttribute UserDto userDto) {
      User user = userService.userRegister(userDto);
      ModelAndView modelAndView=new ModelAndView();
      modelAndView.setViewName("login");
      modelAndView.addObject(user);
      return modelAndView;
   }

   @PostMapping("/login")
   public ModelAndView login(@ModelAttribute UserDto userDto, HttpSession httpSession,ModelAndView modelAndView) {
      User user = userService.login(userDto);
      if(Objects.isNull(user)) {
         modelAndView.addObject("error", "Incorrect Username & Password");
         modelAndView.setViewName("login");
         return modelAndView;
      }

      modelAndView.setViewName("dashboard");
      modelAndView.addObject(user);
      httpSession.setAttribute("userId",user.getUserId());
      return modelAndView;
   }

   @PostMapping("/add/contact")
   public ModelAndView addContact(@ModelAttribute Contact contact,HttpSession httpSession,ModelAndView modelAndView) {
    if(Objects.isNull((Long)(httpSession.getAttribute("userId")))) {
       modelAndView.setViewName("login");

       return modelAndView;
    }
     User user=userService.AddContacts(contact,(Long)(httpSession.getAttribute("userId")));
      modelAndView.setViewName("dashboard");
      if(!user.getContactList().isEmpty())
      modelAndView.addObject("contact",user.getContactList());
      return modelAndView;
   }






}
