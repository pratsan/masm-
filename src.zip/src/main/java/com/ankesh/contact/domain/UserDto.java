package com.ankesh.contact.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserDto {
    private String emailId;
    private String password;
    private String secretCode;

}
