package com.ankesh.contact.domain;

public class ResponseDto {
}
