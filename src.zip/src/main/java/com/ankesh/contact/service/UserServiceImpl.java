package com.ankesh.contact.service;

import com.ankesh.contact.domain.Contact;
import com.ankesh.contact.domain.User;
import com.ankesh.contact.domain.UserDto;
import com.ankesh.contact.repo.ContactRepo;
import com.ankesh.contact.repo.UserRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Optional;
@Slf4j
@Service
public class UserServiceImpl {
@Autowired
private UserRepo userRepo;
@Autowired
private ContactRepo  contactRepo;
public User userRegister(UserDto userDto) {
    User user=new User();
    try{
    user=new User();
    BeanUtils.copyProperties(userDto,user);
    user=userRepo.save(user);
}
catch(Exception exception) {
    return user;
}
return user;
}
    public User login(UserDto userDto) {
     User user=null;
        try{

           Optional<User> userOptional= userRepo.findByEmailIdAndPassword(userDto.getEmailId(), userDto.getPassword());
        if(userOptional.isPresent())
                user=userOptional.get();
        log.info(user.getEmailId());
        }
        catch(Exception exception) {
log.error(exception.getMessage());
        }
        return user;
    }
    public User AddContacts(Contact contact,Long userId) {
     User user=new User();
        try{

            Optional<User> userOptional= userRepo.findById(userId);
            if(userOptional.isPresent()) {
                user = userOptional.get();
                contact.setUser(user);
                contactRepo.save(contact);
//                user.setContactList(Arrays.asList(contact));
//                user = userRepo.save(user);
                user.getContactList().add(contact);
            }
        }
        catch(Exception exception) {

        }
        return user;
    }

}
